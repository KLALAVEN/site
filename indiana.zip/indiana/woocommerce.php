<?php get_header(); ?>
<div class="container">
    	<div class="pagelayout_area">
			<?php woocommerce_content(); ?>
		</div><!-- pagelayout_area -->
</div><!-- container -->     
<?php get_footer(); ?>